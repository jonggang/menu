package com.example.hyunj.ewhan_1_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        final TextView restaurantName_textview=(TextView)findViewById(R.id.restaurantName_textview);
        final TextView information_textview=(TextView)findViewById(R.id.information_textview);
        final TextView menu_textview=(TextView)findViewById(R.id.menu_textview);


        //텍스트뷰에 들어갈 텍스트를 설정하는 코드 > 변수이름.setText()
    }
}
